# 💡 Aprend.AI — Sistema Inteligente Modular

Bem-vindo ao **Aprend.AI v1**, um sistema de inteligência artificial modular desenvolvido em português.

## Estrutura
- servidor/
- interface_web/
- aplicacao_mobile/
- scripts/
- Guia_Tecnico_AprendAI.md

## 🚀 Instalação rápida
git clone https://github.com/seu-utilizador/aprend-ai.git
cd aprend-ai\servidor
pip install -r requisitos.txt
python principal.py

## 🧩 Equipa
**Equipa Aprend.AI Systems** — © 2025
